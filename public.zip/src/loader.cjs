async function loadApp() {
  await import("./server.mjs");
}

loadApp();
